 /* ( function(exports, require, module, _filename, _dirname){
    const a = require("fs");
    const name = "Anchal";
    console.log(name);
    module.exports = {dkfjdkssdkl}
}); */

console.log(__dirname);
console.log(__filename);
