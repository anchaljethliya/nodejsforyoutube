const path = require("path");
console.log(path.dirname("https://www.uber.com/in/en/.js"));

console.log(path.extname("https://www.uber.com/in/en/.js"));