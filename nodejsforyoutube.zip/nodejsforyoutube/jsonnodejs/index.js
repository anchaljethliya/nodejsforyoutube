const fs = require("fs");
const bioData = {
    name : "Anchal",
age : 26,
channel : "anchalkizindagi"
};
 /*const jsonData = JSON.stringify(bioData);     // strigify when obj to json
console.log(jsonData);

const objData = JSON.parse(jsonData);
console.log(objData); */

const jsonData = JSON.stringify(bioData);
 /* fs.writeFile("json1.json", jsonData,(err) =>{
    console.log("done");
});*/

fs.readFile("json1.json" , "utf-8" ,(err,data) => {
     // console.log(data);
     const orgData = JSON.parse(data);
     console.log(data);
     console.log(orgData);
});
