// the http.createserver() method includes req and responses parameters whic is supplied by node.js
// the req object can be used to get info about current http req
//eg: url,req header,and data
//the response object can be used to send a resp for current
//if the responnse from http server is supposed to be displayed
//you should include an http header with the coorect content 


const http = require("http");

const server = http.createServer((req, res) => {
    //console.log(req.url);
    if (req.url == "/"){
res.end("Hello from the others sides");
    }
    else if (req.url == "/about"){
        res.end("Hello from the AboutUs sides");
    }
    else if (req.url == "/contact"){
        res.end("Hello from the contactUs sides");
    } else {
        res.writeHead(404)
        res.end("404 error");
    }
});

server.listen(8000, "127.0.0.1",() => {
console.log("listening to the port no 8000");
});