const fs = require("fs");
fs.writeFile("read.txt","today is awsm day :)",(err) => {
     console.log("file is created");
     console.log(err);
});

//async
//we pass them a func as an arrgument -a callback -
//that gets called when that task completes
//the callback has an argument that tells you whether
//the operatiom completed successly
//now we need to say what to do when fs.writeFile
//has completed (even if it's nothing); and start
//checking for errors

 //fs.appendFile("read.txt","plz like share subscribe",(err) => {
   // console.log("task completed");
// });
fs.readFile("read.txt", "utf-8" , (err,data) => {
    console.log(data);
})