const add = (a,b) => {
return a+b;
}
const sub = (a,b) => {
    return a-b;
    }
    const name = "Anchal";
module.exports.add = add;
module.exports.add = sub;