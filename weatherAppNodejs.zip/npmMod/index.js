  const chalk = require("chalk");
const validator = require("validator");
 // console.log(chalk.blue.italic.underline.inverse("Hello world!"));

 console.log(chalk.red.underline.inverse("false"));

 const res = validator.isEmail("anchaljethliya@gmail.com");
 // console.log(res);
 console.log(res ? chalk.green.inverse(res) : chalk.red.inverse(res));